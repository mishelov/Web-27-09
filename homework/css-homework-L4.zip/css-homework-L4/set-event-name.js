/* To change the name of event just change the content between double quotes */

$('h2').text("Event name");

/* If you want to change the Tags */

$('.tag-one').text("Tag 1");
$('.tag-two').text("Tag 2");
$('.tag-three').text("Tag 3");
$('.tag-four').text("Tag 4");


/* If you want to change suitable for: please change visitors with your preferences */

$('.suit-one').text("Visitor 1");
$('.suit-two').text("Visitor 2");
$('.suit-three').text("Visitor 3");


